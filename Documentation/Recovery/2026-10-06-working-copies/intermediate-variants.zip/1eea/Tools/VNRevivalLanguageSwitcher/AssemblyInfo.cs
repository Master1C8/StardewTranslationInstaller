using System.Reflection;

[assembly: AssemblyTitle("VNRevival.LanguageSwitcher")]
[assembly: AssemblyProduct("VNRevival.LanguageSwitcher")]
[assembly: AssemblyVersion("1.5.0.0")]
[assembly: AssemblyFileVersion("1.5.0.0")]
[assembly: AssemblyInformationalVersion("1.5.0")]
